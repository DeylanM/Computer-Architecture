import java.io.File;
import java.io.FileNotFoundException;
import java.util.Hashtable;
import java.util.Scanner;

public class Parser {

	// current is the current command, i.e., the command that the Parser
	// should act on. next is the next command that the Parser will work on.
	// Do NOT do anything with next.
	private String current, next;
	
	// scanner is used by getNextCommand(). Do NOT use it yourself.
	private Scanner scanner;
	private boolean hasMoreCommands;

	
	public Parser(File src) {
		hasMoreCommands = true;

		try {
			scanner = new Scanner(src);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		}

		current = "";
		next = getNextCommand();
	}

	
	public boolean hasMoreCommands() {
		return hasMoreCommands;
	}

	
	public void advance() {
		current = next;
		next = getNextCommand();
	}
	
	
	// Complete the following three methods: commandType(), arg1(), and arg2().
	// Each method currently returns a "dummy" value to satisfy the compiler.

	public CommandType commandType() {
		String[] words = getWords();
		if (words[0].equals("add") | words[0].equals("sub") | words[0].equals("neg") | words[0].equals("eq") | words[0].equals("gt") | words[0].equals("lt") |words[0].equals("and") |
		words[0].equals("or") | words[0].equals("not")) {
			return CommandType.C_ARITHMETIC;
		}
		if (words[0].equals("push")) {
			return CommandType.C_PUSH;
			
		}
		if (words[0].equals("pop")) {
			return CommandType.C_POP;
			
		}
		if (words[0].equals("goto")) {
			return CommandType.C_GOTO;
			
		}
		if (words[0].equals("label")) {
			return CommandType.C_LABEL;
			
		}
		if (words[0].equals("if-goto")) {
			return CommandType.C_IF;
			
		}
		if (words[0].equals("function")) {
			return CommandType.C_FUNCTION;
			
		}
		if (words[0].equals("return")) {
			return CommandType.C_RETURN;
			
		}
		if (words[0].equals("call")) {
			return CommandType.C_CALL;
			
		}
		return null;
	}
	public String arg1() {
		String[] words = getWords();
		if (commandType() == CommandType.C_RETURN) {
			System.exit(0);
			return null;
		}
		else if (commandType() == CommandType.C_ARITHMETIC) {
			return words[0];
			
		
			
		}
		return words[1];
	}

	
	public int arg2() {
		String[] words = getWords();
		if (commandType() == CommandType.C_PUSH || commandType() == CommandType.C_POP || commandType() == CommandType.C_FUNCTION || commandType() == CommandType.C_CALL) {
			return Integer.parseInt(words[2]);
	}
		return -1;
	}
	
	// Do NOT make ANY changes to the following methods.

	
	private String getNextCommand() {
		String next;

		// The following regular expression matches any line that is all
		// whitespace or is only a comment. Continue scanning the input
		// file until we get an actual command or empty the file.

		do {
			if (scanner.hasNextLine())
				next = scanner.nextLine();
			else {
				hasMoreCommands = false;
				return "";
			}
		} while (next.matches("(^\\s*$)|(^\\s*//.*$)"));

		return next;
	}

	
	// Returns the words of the current command as a String array.
	// For example, if the current command is
	// push local 3
	// this methods returns a String array in which
	// index 0 is "push"
	// index 1 is "local"
	// index 2 is "3"

	private String[] getWords() {
		return current.split("\\s+");
	}
}
