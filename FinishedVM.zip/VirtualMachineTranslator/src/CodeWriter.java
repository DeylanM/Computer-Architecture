import java.io.FileWriter;
import java.io.IOException;

public class CodeWriter {

	// The HACK asm file we're writing the translated VM commands to.
	private FileWriter asmFile;
	
	// Basename of the current .vm file we're translated.  Used for push/pop commands
	// to/from the static segment
	private String fileName = "";
	
	// functioName is used in the second part of the VM translator, Project 8.
	// It is set in writeFunction() and used in writeLabel(), writeIf(), and writeCall(). 
	private String functionName = "";
	
	int counter = 0;
	

	
	
	public CodeWriter(String basename) {
		try { // Open the ASM file for writing.
			asmFile = new FileWriter(basename + ".asm");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}
	public String emitPush(String seg, int idx) {
		String code = "";
		System.out.print(idx);
		switch (seg) {
			case "constant":
				code = "@" + idx + "\n"
						+ "D=A\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "static":
				code = "@" + fileName+ "." + idx + "\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "local":
				code = "@LCL\n"
						+ "D=M\n"
						+ "@" + idx + "\n"
						+ "A=D+A\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "this":
				code = "@THIS\n"
						+ "D=M\n"
						+ "@"+ idx + "\n"
						+ "A=D+A\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "that":
				code = "@THAT\n"
						+ "D=M\n"
						+ "@" + idx + "\n"
						+ "A=D+A\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "argument":
				code = "@ARG\n"
						+ "D=M\n"
						+ "@" + idx + "\n"
						+ "A=D+A\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "temp":
				code = "@" + (idx + 5) + "\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			case "pointer":
				code = "@" + (idx + 3) + "\n"
						+ "D=M\n"
						+ "@SP\n"
						+ "AM=M+1\n"
						+ "A=A-1\n"
						+ "M=D\n";
				break;
			
		}
		return code;
	}
	public String emitPop(String seg, int idx) {
		String code = "";
		switch (seg) {
			case "static":
				code = "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@" + fileName + "." +idx+ "\n"
						+ "M=D\n";
				break;
			case "constant":
				code = "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@" +idx+ "\n"
						+ "M=D\n";
				break;
			case "local":
				code = "@LCL\n"
						+ "D=M\n"
						+ "@"+idx+"\n"
						+ "D=D+A\n"
						+ "@R15\n"
						+ "M=D\n"
						+ "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@R15\n"
						+ "A=M\n"
						+ "M=D\n";
				break;
			case "this":
				code = "@THIS\n"
						+ "D=M\n"
						+ "@"+idx+"\n"
						+ "D=D+A\n"
						+ "@R15\n"
						+ "M=D\n"
						+ "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@R15\n"
						+ "A=M\n"
						+ "M=D\n";
				break;
			case "that":
				code = "@THAT\n"
						+ "D=M\n"
						+ "@"+idx+"\n"
						+ "D=D+A\n"
						+ "@R15\n"
						+ "M=D\n"
						+ "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@R15\n"
						+ "A=M\n"
						+ "M=D\n";
				break;
			case "argument":
				code = "@ARG\n"
						+ "D=M\n"
						+ "@"+idx+"\n"
						+ "D=D+A\n"
						+ "@R15\n"
						+ "M=D\n"
						+ "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@R15\n"
						+ "A=M\n"
						+ "M=D\n";
				break;
			case "temp":
				code = "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@" +(idx+ 5) + "\n"
						+ "M=D\n";
				break;
			case "pointer":
				code = "@SP\n"
						+ "AM=M-1\n"
						+ "D=M\n"
						+ "@" +(idx+ 3) + "\n"
						+ "M=D\n";
				break;
			
		}
		return code;
	}
	// This is a helper method.
	// Write a sequence of ASM code to the ASM file.
	// The parameter code is expected to contain all necessary newline
	// characters.
	private void writeCode(String code) {
		try {
			asmFile.write(code);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	
	public void setFileName(String fileName) {
		this.fileName = fileName;
		functionName = "";
	}

	
	public void close() {
		try {
			asmFile.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	
	public void writeArithmetic(String op) {
		String code = "";
		switch (op) {
        case "add":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nM=M+D\n";
            break;
        case "sub":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nM=M-D\n";
            break;
        case "and":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nM=M&D\n";
            break;
        case "or":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nM=M|D\n";
            break;
        case "neg": 
            code = "@SP\nA=M-1\nM=-M\n\n";
            break;
        case "eq":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\nM=-1\n@__"+ counter +"\nD;JEQ\n@SP\nA=M-1\nM=0\n(__"+ counter +")\n";
            counter++;
            break;
        case "lt":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\nM=-1\n@__"+ counter +"\nD;JLT\n@SP\nA=M-1\nM=0\n(__"+ counter +")\n";
            counter++;
            break;
        case "gt":
            code = "@SP\nAM=M-1\nD=M\nA=A-1\nD=M-D\nM=-1\n@__"+ counter +"\nD;JGT\n@SP\nA=M-1\nM=0\n(__"+ counter +")\n";
            counter++;
            break;
        case "not":
        	code = "@SP\r\n"
        			+ "A=M-1\r\n"
        			+ "M=!M\n";
        	break;
        		
        	
        default:
            code = "";
    }

    writeCode(code);
	}

	
	public void writePushPop(CommandType op, String seg, int idx) {
		String code = "";
		
		if (op == CommandType.C_PUSH)
			code = emitPush(seg,idx);
		else
			code = emitPop(seg,idx);

		// Add code completing the method here.

		writeCode(code);
	}
	
	
	/***********************************************************************
	 * The following methods will be completed for the second part of the
	 * VM translator, Project 8.
	 ***********************************************************************/

	
	public void writeInit() {
		String code = "@256\nD=A\n@SP\nM=D\n";
		writeCode(code);
		writeCall("Sys.init",0);
		// Add code completing the method here.

	}

	
	public void writeLabel(String label) {
		String code = "("+ functionName + "$" + label + ")\n";

		// Add code completing the method here.

		writeCode(code);
	}

	
	public void writeGoto(String label) {
		writeCode("@" + functionName + "$" + label + "\n0;JMP\n");

		// Add code completing the method here.

	}

	
	public void writeIf(String label) {
		writeCode("@SP\nAM=M-1\nD=M\n@" + functionName + "$" + label + "\nD;JNE\n");

		// Add code completing the method here.

	}

	
	public void writeCall(String fName, int nArgs) {
		functionName = fName;
		writeCode("@__"+counter+"\nD=A\n@SP\nAM=M+1\nA=A-1\nM=D\n@LCL\nD=M\n@SP\n"
                + "AM=M+1\nA=A-1\nM=D\n@ARG\nD=M\n@SP\nAM=M+1\nA=A-1\nM=D\n@THIS\n"
                + "D=M\n@SP\nAM=M+1\nA=A-1\nM=D\n@THAT\nD=M\n@SP\nAM=M+1\nA=A-1\nM=D\n"
                + "@SP\nD=M\n@"+Integer.toString(nArgs+5)+"\nD=D-A\n@ARG\nM=D\n"
                + "@SP\nD=M\n@LCL\nM=D\n@"+fName+"\n0;JMP\n(__"+counter+")\n");
		counter++;
	}

	
	public void writeReturn() {
		writeCode("@LCL\nD=M\n@R13\nM=D\n@5\nA=D-A\nD=M\n@R14\nM=D\n@SP\n"
                + "AM=M-1\nD=M\n@ARG\nA=M\nM=D\n@ARG\nD=M+1\n@SP\nM=D\n@R13\n"
                + "AM=M-1\nD=M\n@THAT\nM=D\n@R13\nAM=M-1\nD=M\n@THIS\nM=D\n"
                + "@R13\nAM=M-1\nD=M\n@ARG\nM=D\n@R13\nAM=M-1\nD=M\n@LCL\nM=D\n"
                + "@R14\nA=M\n0;JMP\n");
	}

	
	public void writeFunction(String fName, int nLocals) {
		String code = "";
		functionName = fName;
		code = "("+ fName +") \n";
		for (int i = 0; i<nLocals; i++) {
			code = code + "@SP\n AM=M+1\nA=A-1\nM=0\n";
		}
		writeCode(code);
		// Add code completing the method here.
	}
}